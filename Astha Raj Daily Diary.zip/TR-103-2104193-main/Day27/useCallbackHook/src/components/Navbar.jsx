import React from 'react'

const Navbar = ({adjective}) => {
  return (
    <div>
      I am a {adjective} Navbar
    </div>
  )
}

export default Navbar
