import React from 'react'

const Contact = () => {
  return (
    <div>
      I am Contact
    </div>
  )
}

export default Contact
