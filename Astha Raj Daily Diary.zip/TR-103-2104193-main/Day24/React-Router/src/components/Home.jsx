import React from 'react'

const Home = () => {
  return (
    <div>
      I am home
    </div>
  )
}

export default Home
