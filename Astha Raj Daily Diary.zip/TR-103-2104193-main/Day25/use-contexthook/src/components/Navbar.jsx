import React from 'react'
import Button from './Button'

const Navbar = () => {
  return (
    <div>
      <Button />
    </div>
  )
}

export default Navbar
