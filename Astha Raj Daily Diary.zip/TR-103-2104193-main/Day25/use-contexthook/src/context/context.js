import { createContext } from "react";
export const countContext=createContext()