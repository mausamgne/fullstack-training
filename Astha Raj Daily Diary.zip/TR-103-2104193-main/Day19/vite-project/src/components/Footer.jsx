import React from 'react'
import './Footer.css'
const Footer = () => {
  return (
    <footer>
      Copyright &copy; simarpreetCoder | All Rights Reserved@2024
    </footer>
  )
}

export default Footer
